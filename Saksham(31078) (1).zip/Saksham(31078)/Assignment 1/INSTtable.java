import java.util.*;

public class INSTtable {
    HashMap<String,Integer> AD, IS, DL, RG, CC;

    public INSTtable() {
        AD = new HashMap<>();
        IS = new HashMap<>();
        DL = new HashMap<>();
        RG = new HashMap<>();
        CC = new HashMap<>();

        // Assembler directives
        AD.put("START", 1);
        AD.put("END", 2);
        AD.put("ORIGIN", 3);
        AD.put("EQU", 4);
        AD.put("LTORG", 5);

        // Declarative
        DL.put("DC", 1);
        DL.put("DS", 2);

        // Imperative
        IS.put("STOP", 0);
        IS.put("ADD", 1);
        IS.put("SUB", 2);
        IS.put("MULT", 3);
        IS.put("MOVER", 4);
        IS.put("MOVEM", 5);
        IS.put("COMP", 6);
        IS.put("BC", 7);
        IS.put("DIV", 8);
        IS.put("READ", 9);
        IS.put("PRINT", 10);

        // Registers
        RG.put("AREG", 1);
        RG.put("BREG", 2);
        RG.put("CREG", 3);
        RG.put("DREG", 4);

        // Condition codes
        CC.put("LT", 1);
        CC.put("LE", 2);
        CC.put("EQ", 3);
        CC.put("GT", 4);
        CC.put("GE", 5);
        CC.put("ANY", 6);
    }

    public String getType(String s) {
        s = s.toUpperCase();
        if (AD.containsKey(s)) return "AD";
        if (IS.containsKey(s)) return "IS";
        if (DL.containsKey(s)) return "DL";
        if (RG.containsKey(s)) return "RG";
        if (CC.containsKey(s)) return "CC";
        return "";
    }

    public int getCode(String s) {
        s = s.toUpperCase();
        if (AD.containsKey(s)) return AD.get(s);
        if (IS.containsKey(s)) return IS.get(s);
        if (DL.containsKey(s)) return DL.get(s);
        if (RG.containsKey(s)) return RG.get(s);
        if (CC.containsKey(s)) return CC.get(s);
        return -1;
    }
}
