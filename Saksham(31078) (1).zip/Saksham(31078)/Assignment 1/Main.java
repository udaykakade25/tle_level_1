import java.io.*;
import java.util.*;

public class PassOne {
    int lc = 0;  
    int symIndex = 0, litIndex = 0, poolIndex = 0;

    LinkedHashMap<String, TableRow> SYMTAB = new LinkedHashMap<>();
    ArrayList<TableRow> LITTAB = new ArrayList<>();
    ArrayList<Integer> POOLTAB = new ArrayList<>();

    public static void main(String[] args) {
        PassOne assembler = new PassOne();
        assembler.run();
    }

    public void run() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("input.asm"));
            BufferedWriter icWriter = new BufferedWriter(new FileWriter("IC.txt"));
            INSTtable lookup = new INSTtable();
            POOLTAB.add(0); // first literal pool

            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.trim().split("\\s+");
                String label = (parts.length > 0) ? parts[0] : "";
                String opcode = (parts.length > 1) ? parts[1] : "";
                String operand = (parts.length > 2) ? parts[2] : "";

                // START
                if (opcode.equals("START")) {
                    lc = Integer.parseInt(operand);
                    icWriter.write("(AD,01)\t(C," + lc + ")\n");
                    continue;
                }

                // If label exists, put in SYMTAB
                if (!label.isEmpty() && lookup.getType(label).equals("")) {
                    if (!SYMTAB.containsKey(label)) {
                        SYMTAB.put(label, new TableRow(label, lc, ++symIndex));
                    } else {
                        SYMTAB.put(label, new TableRow(label, lc, SYMTAB.get(label).getIndex()));
                    }
                }

                // DS
                if (opcode.equals("DS")) {
                    int size = Integer.parseInt(operand);
                    icWriter.write("(DL,02)\t(C," + size + ")\n");
                    lc += size;
                    continue;
                }

                // DC
                if (opcode.equals("DC")) {
                    int value = Integer.parseInt(operand.replace("'", ""));
                    icWriter.write("(DL,01)\t(C," + value + ")\n");
                    lc++;
                    continue;
                }

                // EQU
                if (opcode.equals("EQU")) {
                    int addr = SYMTAB.get(operand.split("\\+")[0]).getAddess() + 1;
                    SYMTAB.put(label, new TableRow(label, addr, ++symIndex));
                    icWriter.write("(AD,04)\t(C," + addr + ")\n");
                    continue;
                }

                // ORIGIN
                if (opcode.equals("ORIGIN")) {
                    String[] splits = operand.split("\\+");
                    lc = SYMTAB.get(splits[0]).getAddess() + Integer.parseInt(splits[1]);
                    icWriter.write("(AD,03)\t(S," + SYMTAB.get(splits[0]).getIndex() + ")+" + splits[1] + "\n");
                    continue;
                }

                // END
                if (opcode.equals("END")) {
                    icWriter.write("(AD,02)\n");
                    continue;
                }

                // Imperative Statement
                if (lookup.getType(opcode).equals("IS")) {
                    String ic = "(IS,0" + lookup.getCode(opcode) + ")\t";
                    String code2 = "";

                    for (int j = 2; j < parts.length; j++) {
                        String op = parts[j].replace(",", "");
                        String type = lookup.getType(op);

                        if (type.equals("RG")) {
                            code2 += lookup.getCode(op) + "\t";
                        } else if (op.startsWith("=")) {
                            String litVal = op.replace("=", "").replace("'", "");
                            LITTAB.add(new TableRow(litVal, -1, ++litIndex));
                            code2 += "(L," + litIndex + ")";
                        } else {
                            if (!SYMTAB.containsKey(op)) {
                                SYMTAB.put(op, new TableRow(op, -1, ++symIndex));
                            }
                            int idx = SYMTAB.get(op).getIndex();
                            code2 += "(S," + idx + ")";
                        }
                    }
                    icWriter.write(ic + code2 + "\n");
                    lc++;
                }
            }

            icWriter.close();
            br.close();

            printSYMTAB();
            printLITTAB();
            printPOOLTAB();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void printSYMTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("SYMTAB.txt"));
        System.out.println("SYMBOL TABLE:");
        for (String key : SYMTAB.keySet()) {
            TableRow row = SYMTAB.get(key);
            System.out.println(row.getIndex() + " " + row.getSymbol() + " " + row.getAddess());
            bw.write(row.getIndex() + " " + row.getSymbol() + " " + row.getAddess() + "\n");
        }
        bw.close();
    }

    void printLITTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("LITTAB.txt"));
        System.out.println("\nLITERAL TABLE:");
        for (int i = 0; i < LITTAB.size(); i++) {
            TableRow row = LITTAB.get(i);
            System.out.println((i+1) + " " + row.getSymbol() + " " + row.getAddess());
            bw.write((i+1) + " " + row.getSymbol() + " " + row.getAddess() + "\n");
        }
        bw.close();
    }

    void printPOOLTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("POOLTAB.txt"));
        System.out.println("\nPOOL TABLE:");
        for (int i = 0; i < POOLTAB.size(); i++) {
            System.out.println((i+1) + " " + POOLTAB.get(i));
            bw.write((i+1) + " " + POOLTAB.get(i) + "\n");
        }
        bw.close();
    }
}
