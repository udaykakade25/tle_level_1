public class TableRow {
    String symbol;
    int addess, index;

    public TableRow(String symbol, int addess, int index) {
        this.symbol = symbol;
        this.addess = addess;
        this.index = index;
    }

    public String getSymbol() { return symbol; }
    public int getAddess() { return addess; }
    public int getIndex() { return index; }
}
