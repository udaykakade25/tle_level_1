import java.io.*;
import java.util.*;

public class PassOne {
    int lc = 0;  
    int symIndex = 0, litIndex = 0;

    LinkedHashMap<String, TableRow> SYMTAB = new LinkedHashMap<>();
    ArrayList<TableRow> LITTAB = new ArrayList<>();
    ArrayList<Integer> POOLTAB = new ArrayList<>();

    public static void main(String[] args) {
        PassOne assembler = new PassOne();
        assembler.run();
    }

    public void run() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("input.asm"));
            BufferedWriter icWriter = new BufferedWriter(new FileWriter("IC.txt"));
            INSTtable lookup = new INSTtable();
            POOLTAB.add(0); // first literal pool

            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.trim().split("\\s+");

                String label = "";
                String opcode = "";
                String operand = "";

                // --- Detect label vs opcode ---
                if (parts.length == 1) {
                    opcode = parts[0]; // e.g. STOP, END
                } else if (lookup.getType(parts[0]).equals("IS") || lookup.getType(parts[0]).equals("DL") || lookup.getType(parts[0]).equals("AD")) {
                    opcode = parts[0]; // first token is instruction
                    if (parts.length > 1) operand = parts[1];
                } else {
                    label = parts[0]; // first token is a label
                    if (parts.length > 1) opcode = parts[1];
                    if (parts.length > 2) operand = parts[2];
                }

                // --- START ---
                if (opcode.equals("START")) {
                    if (!operand.isEmpty()) {
                        lc = Integer.parseInt(operand);
                        icWriter.write("(AD,01)\t(C," + lc + ")\n");
                    }
                    continue;
                }

                // --- If label exists and not mnemonic, add/update SYMTAB ---
                if (!label.isEmpty() && lookup.getType(label).equals("")) {
                    if (!SYMTAB.containsKey(label)) {
                        SYMTAB.put(label, new TableRow(label, lc, ++symIndex));
                    } else {
                        TableRow existing = SYMTAB.get(label);
                        SYMTAB.put(label, new TableRow(label, lc, existing.getIndex()));
                    }
                }

                // --- DS ---
                if (opcode.equals("DS")) {
                    int size = Integer.parseInt(operand);
                    icWriter.write("(DL,02)\t(C," + size + ")\n");
                    lc += size;
                    continue;
                }

                // --- DC ---
                if (opcode.equals("DC")) {
                    int value = Integer.parseInt(operand.replace("'", ""));
                    icWriter.write("(DL,01)\t(C," + value + ")\n");
                    lc++;
                    continue;
                }

                // --- EQU ---
                if (opcode.equals("EQU")) {
                    int addr = 0;
                    if (operand.contains("+")) {
                        String[] splits = operand.split("\\+");
                        addr = SYMTAB.get(splits[0]).getAddess() + Integer.parseInt(splits[1]);
                    } else if (operand.contains("-")) {
                        String[] splits = operand.split("\\-");
                        addr = SYMTAB.get(splits[0]).getAddess() - Integer.parseInt(splits[1]);
                    } else {
                        addr = SYMTAB.get(operand).getAddess();
                    }
                    if (SYMTAB.containsKey(label)) {
                        TableRow existing = SYMTAB.get(label);
                        SYMTAB.put(label, new TableRow(label, addr, existing.getIndex()));
                    } else {
                        SYMTAB.put(label, new TableRow(label, addr, ++symIndex));
                    }
                    icWriter.write("(AD,04)\t(C," + addr + ")\n");
                    continue;
                }

                // --- ORIGIN ---
                if (opcode.equals("ORIGIN")) {
                    if (operand.contains("+")) {
                        String[] splits = operand.split("\\+");
                        lc = SYMTAB.get(splits[0]).getAddess() + Integer.parseInt(splits[1]);
                        icWriter.write("(AD,03)\t(S," + SYMTAB.get(splits[0]).getIndex() + ")+" + splits[1] + "\n");
                    } else if (operand.contains("-")) {
                        String[] splits = operand.split("\\-");
                        lc = SYMTAB.get(splits[0]).getAddess() - Integer.parseInt(splits[1]);
                        icWriter.write("(AD,03)\t(S," + SYMTAB.get(splits[0]).getIndex() + ")-" + splits[1] + "\n");
                    } else {
                        lc = SYMTAB.get(operand).getAddess();
                        icWriter.write("(AD,03)\t(S," + SYMTAB.get(operand).getIndex() + ")\n");
                    }
                    continue;
                }

                // --- END ---
                if (opcode.equals("END")) {
                    icWriter.write("(AD,02)\n");
                    continue;
                }

                // --- Imperative Statement ---
                if (lookup.getType(opcode).equals("IS")) {
                    String ic = "(IS," + String.format("%02d", lookup.getCode(opcode)) + ")\t"; // always 2 digits
                    String code2 = "";

                    int startIndex = label.isEmpty() ? 1 : 2;

                    for (int j = startIndex; j < parts.length; j++) {
                        String op = parts[j].replace(",", "");
                        String type = lookup.getType(op);

                        if (type.equals("RG")) {
                            code2 += lookup.getCode(op) + "\t";
                        } else if (op.startsWith("=")) {
                            String litVal = op.replace("=", "").replace("'", "");
                            LITTAB.add(new TableRow(litVal, -1, ++litIndex));
                            code2 += "(L," + litIndex + ")";
                        } else {
                            if (!SYMTAB.containsKey(op)) {
                                SYMTAB.put(op, new TableRow(op, -1, ++symIndex));
                            }
                            int idx = SYMTAB.get(op).getIndex();
                            code2 += "(S," + idx + ")";
                        }
                    }
                    icWriter.write(ic + code2 + "\n");
                    lc++;
                }
            }

            icWriter.close();
            br.close();

            printSYMTAB();
            printLITTAB();
            printPOOLTAB();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void printSYMTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("SYMTAB.txt"));
        System.out.println("SYMBOL TABLE:");
        for (String key : SYMTAB.keySet()) {
            TableRow row = SYMTAB.get(key);
            System.out.println(row.getIndex() + " " + row.getSymbol() + " " + row.getAddess());
            bw.write(row.getIndex() + " " + row.getSymbol() + " " + row.getAddess() + "\n");
        }
        bw.close();
    }

    void printLITTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("LITTAB.txt"));
        System.out.println("\nLITERAL TABLE:");
        for (int i = 0; i < LITTAB.size(); i++) {
            TableRow row = LITTAB.get(i);
            System.out.println((i+1) + " " + row.getSymbol() + " " + row.getAddess());
            bw.write((i+1) + " " + row.getSymbol() + " " + row.getAddess() + "\n");
        }
        bw.close();
    }

    void printPOOLTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("POOLTAB.txt"));
        System.out.println("\nPOOL TABLE:");
        for (int i = 0; i < POOLTAB.size(); i++) {
            System.out.println((i+1) + " " + POOLTAB.get(i));
            bw.write((i+1) + " " + POOLTAB.get(i) + "\n");
        }
        bw.close();
    }
}
