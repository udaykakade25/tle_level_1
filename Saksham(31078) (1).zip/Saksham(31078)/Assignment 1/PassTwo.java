import java.io.*;
import java.util.*;

public class PassTwo {

    static class Symbol {
        int index;
        String symbol;
        int address;
        Symbol(int i, String s, int a) {
            index = i; symbol = s; address = a;
        }
    }

    static Map<Integer, Symbol> SYMTAB = new HashMap<>();

    public static void main(String[] args) {
        try {
            loadSYMTAB("SYMTAB.txt");
            generateMachineCode("IC.txt", "MACHINECODE.txt");
            System.out.println("Machine code generated in MACHINECODE.txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void loadSYMTAB(String file) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.trim().split("\\s+");
            if (parts.length >= 3) {
                int idx = Integer.parseInt(parts[0]);
                String sym = parts[1];
                int addr = Integer.parseInt(parts[2]);
                SYMTAB.put(idx, new Symbol(idx, sym, addr));
            }
        }
        br.close();
    }

    static void generateMachineCode(String icFile, String mcFile) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(icFile));
        BufferedWriter bw = new BufferedWriter(new FileWriter(mcFile));
        String line;

        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            // Skip Assembler Directives
            if (line.startsWith("(AD")) continue;
            if (line.startsWith("(DL,02)")) continue; // skip DS (reserve space only)

            String opcode = "00";
            String reg = "0";
            String mem = "0";

            String[] parts = line.split("\\s+");

            if (parts[0].startsWith("(IS,")) {
                opcode = parts[0].replace("(IS,", "").replace(")", "");
            } else if (parts[0].startsWith("(DL,01)")) {
                opcode = "00"; // DC generates data line
            }

            for (int i = 1; i < parts.length; i++) {
                String token = parts[i];

                if (token.matches("\\d")) {
                    reg = token;
                } else if (token.startsWith("(S,")) {
                    int idx = Integer.parseInt(token.replace("(S,", "").replace(")", ""));
                    if (SYMTAB.containsKey(idx)) {
                        mem = String.valueOf(SYMTAB.get(idx).address);
                    }
                } else if (token.startsWith("(C,")) {
                    mem = token.replace("(C,", "").replace(")", "");
                }
            }

            bw.write(opcode + "\t" + reg + "\t" + mem + "\n");
        }

        br.close();
        bw.close();
    }
}
