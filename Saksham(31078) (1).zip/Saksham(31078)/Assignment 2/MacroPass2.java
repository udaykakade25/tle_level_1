import java.io.*;
import java.util.*;

public class MacroPass2 {
    public static void main(String[] args) {
        List<String> mdt = new ArrayList<>();
        Map<String, Integer> mnt = new LinkedHashMap<>();

        // --- Load MDT and MNT from Pass-I (hardcoded for demo; ideally save to file) ---
        mdt.add("ADD #0,#1");
        mdt.add("L #0");
        mdt.add("ST #1");
        mdt.add("MEND");
        mnt.put("ADD", 0);

        mdt.add("FIND #0");
        mdt.add("N #0");
        mdt.add("MEND");
        mnt.put("FIND", 4);

        try (BufferedReader br = new BufferedReader(new FileReader("intermediate.txt"));
             PrintWriter writer = new PrintWriter(new FileWriter("finalOutput.txt"))) {

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] tokens = line.split("\\s+", 2);
                String op = tokens[0];

                if (mnt.containsKey(op)) {
                    // Expand macro
                    int start = mnt.get(op);
                    List<String> actualArgs = new ArrayList<>();   // ✅ renamed

                    if (tokens.length > 1) {
                        actualArgs.addAll(Arrays.asList(tokens[1].split(",")));
                    }

                    for (int i = start; i < mdt.size(); i++) {
                        String macroLine = mdt.get(i);
                        if (macroLine.equals("MEND")) break;

                        String expanded = macroLine;
                        for (int j = 0; j < actualArgs.size(); j++) {
                            expanded = expanded.replace("#" + j, actualArgs.get(j));
                        }
                        writer.println(expanded);
                        System.out.println(expanded);
                    }
                } else {
                    writer.println(line);
                    System.out.println(line);
                }
            }

            System.out.println("Final expanded code written to finalOutput.txt");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
